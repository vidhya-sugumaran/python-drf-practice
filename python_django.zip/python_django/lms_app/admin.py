from django.contrib import admin
from .models import LMS
admin.site.register(LMS)
